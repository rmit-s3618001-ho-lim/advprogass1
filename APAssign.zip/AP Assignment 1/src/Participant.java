
public class Participant {
	
	private String ID;
	private String name;
	private int age;
	private String state;
	
	public Participant(String IDs, String names, int ages, String states){
		this.ID = IDs;
		name = names;
		age = ages;
		state = states;
	}
	
	public Participant(){}
	
	public String getID(){
		return this.ID;
	}
	
	public String getName(){
		return this.name;
	}
	
	public int getAge(){
		return this.age;
	}
	
	public String getState(){
		return this.state;
	}
	
	

}

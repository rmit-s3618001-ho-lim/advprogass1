
public class Ozlympic {
	
	public static void main(String[] args){
		Driver mydriver = new Driver();
		mydriver.runDriver();
		 
		
	}

}


public abstract class Athletes extends Participant {

	private int points;
	private int time;
	
	public Athletes(String IDs, String names, int ages, String states){
		super(IDs, names, ages, states);
		points = 0;
		time = 0;
	}
	
	public Athletes(){};
	
	public int getPoints(){
		return this.points;
	}
	
	public int getTime(){
		return this.time;
	}
	
	public void setPoints(int pointsWon){
		this.points = points + pointsWon;
	}
	
	public void setTime(int timeCom){
		this.time = timeCom;
	}
	
	public abstract void compete(Game gam, Athletes ath);
	
	public abstract void print();

}

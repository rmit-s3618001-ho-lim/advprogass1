import java.util.ArrayList;
import java.util.Random;

public class CyclingGame extends Game {

	public CyclingGame(String ID, Official off) {
		super(ID, off);
	}

	public CyclingGame() {
	}

	public String IDMaker(int count) {
		StringBuilder build = new StringBuilder();
		build.append("C");
		if (count <= 9) {
			build.append(0);
			build.append(String.valueOf(count));
		} else {
			build.append(String.valueOf(count));
		}
		return build.toString();

	}

	public void chooseCompetitors(Athletes[] competitors, Cyclists[] cyclists, Superathletes[] supers, int number) {
		Random rng = new Random();
		Cyclists cycle = null;
		Superathletes supere = null;
		int count = 0;
		do {
			boolean sameguy = false;
			int athleteschoice = rng.nextInt(2);
			if (athleteschoice == 0) {
				cycle = cyclists[rng.nextInt(cyclists.length)];
				if (competitors[0] == null) {
					competitors[0] = cycle;
					count++;
				} else {
					for (int j = 0; j < count; j++) {
						if (cycle.getID().equalsIgnoreCase(competitors[j].getID())) {
							sameguy = true;
						}
					}
					if (sameguy == true) {
						continue;
					} else {
						competitors[count] = cycle;
						count++;
					}

				}
			} else {
				supere = supers[rng.nextInt(supers.length)];
				if (competitors[0] == null) {
					competitors[0] = supere;
					count++;
				} else {
					for (int j = 0; j < count; j++) {
						if (supere.getID().equalsIgnoreCase(competitors[j].getID())) {
							sameguy = true;
						}
					}
					if (sameguy == true) {
						continue;
					} else {
						competitors[count] = supere;
						count++;
					}
				}
			}
		} while (count < number);

	}

	public void print() {
		String gameID = getGameID();
		Official off = getOfficial();
		System.out.println("--- GAME DETAILS ---");
		System.out.printf("ID: " + gameID);
		System.out.printf("   Type:  Cycling Game");
		System.out.println();
		off.print();
	}

	public void printResults() {
		String gameID = getGameID();
		Official off = getOfficial();
		String type = "Cycling";
		Athletes win1 = getWinner1();
		Athletes win2 = getWinner2();
		Athletes win3 = getWinner3();
		if (win1 != null && win2 != null && win3 != null) {
			System.out.print(String.format(
					"Game ID: %-2s Type: %-9s Official: %-18s Winner 1: %-12s Winner 2: %-12s"
							+ "Winner 3: %s",
					gameID, type, off.getName(), win1.getName(), win2.getName(), win3.getName()));
			System.out.println();
		} else {
			System.out.print(
					String.format("Game ID: %-2s Type: %-9s Official: %-20s (This game was cancelled ior not started)",
							gameID, type, off.getName()));
			System.out.println();
		}
	}

}

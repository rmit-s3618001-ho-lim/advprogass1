import java.util.Random;

public class Sprinters extends Athletes {

	private int points;

	public Sprinters(String IDs, String names, int ages, String states) {
		super(IDs, names, ages, states);
		points = 0;
		// TODO Auto-generated constructor stub
	}

	public Sprinters() {
	}

	public void loadSprinters(Sprinters[] sprinterList) {
		sprinterList[0] = new Sprinters("SP01", "Speedy", 34, "Victoria");
		sprinterList[1] = new Sprinters("SP02", "Zoomer", 50, "S. Australia");
		sprinterList[2] = new Sprinters("SP03", "A Scout", 60, "Victoria");
		sprinterList[3] = new Sprinters("SP04", "Hoely", 99, "NSW");
		sprinterList[4] = new Sprinters("SP05", "Bolt", 12, "Queensland");
	}

	public void compete(Game gam, Athletes run) {
		Random RNG = new Random();
		if (gam instanceof RunningGame) {
			int competeTime = RNG.nextInt(11) + 10;
			run.setTime(competeTime);
		} else {
			System.out.println(run.getName() + " has entered the wrong game.");
		}

	}

	public void print() {
		String sprintID = getID();
		String sprintName = getName();
		int sprintAge = getAge();
		String sprintState = getState();
		int sprintPoints = getPoints();
		System.out.print(String.format("ID: %-5s Name: %-15s Age: %-5s State: %-14s Points: %s", sprintID, sprintName,
				sprintAge, sprintState, sprintPoints));
		System.out.println("");
	}

	
	public void printPoints() {
		String sprintID = getID();
		String sprintName = getName();
		int sprintPoints = getPoints();
		String type = "Sprinter";
		System.out.print(
				String.format("ID: %-5s Name: %-15s Type: %-14s Points: %s", sprintID, sprintName, type, sprintPoints));
		System.out.println("");
	}
}


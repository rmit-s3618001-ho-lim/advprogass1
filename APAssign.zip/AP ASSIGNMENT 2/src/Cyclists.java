

import java.util.Random;

public class Cyclists extends Athletes{

	/* cyclists constructors */
	public Cyclists(String IDs, String types, String names, int ages, String states) {
		super(IDs, types, names, ages, states);
	}

	public Cyclists() {
	}
	
	// randomly generate cyclists' race time for current game //
	public void compete(Game gam, Athletes cycle) {
		Random RNG = new Random();
		if (gam instanceof CyclingGame) {
			int competeTime = RNG.nextInt(301) + 300;
			cycle.setTime(competeTime);
		}

	}

	// prints out the cyclists who are participating in current game information
	// //
	public void print() {
		String cycleID = getID();
		String cycleName = getName();
		int cycleAge = getAge();
		String cycleState = getState();
		int cyclePoints = getPoints();
		System.out.print(String.format("ID: %-5s Name: %-15s Age: %-5s State: %-14s Points: %s", cycleID, cycleName,
				cycleAge, cycleState, cyclePoints));
		System.out.println("");
	}

	// prints out all cyclists ID, name and their points //
	public void printPoints() {
		String cycleID = getID();
		String cycleName = getName();
		int cyclePoints = getPoints();
		String type = "Cyclist";
		System.out.print(
				String.format("ID: %-5s Name: %-15s Type: %-14s Points: %s", cycleID, cycleName, type, cyclePoints));
		System.out.println("");
	}



}

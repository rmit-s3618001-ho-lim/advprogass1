

import java.util.Random;

public class Swimmer extends Athletes {

	/* swimmers constructors */
	public Swimmer(String IDs, String types, String names, int ages, String states) {
		super(IDs, types, names, ages, states);
	}

	public Swimmer() {
	};


	// randomly generate swimmers' race time for current game //
	public void compete(Game gam, Athletes swim) {
		Random RNG = new Random();
		if (gam instanceof SwimmingGame) {
			int competeTime = RNG.nextInt(101) + 100;
			swim.setTime(competeTime);
		}
	}

	// prints out the swimmers who are participating in current game information
	// //
	public void print() {
		String swimID = getID();
		String swimName = getName();
		int swimAge = getAge();
		String swimState = getState();
		int swimPoints = getPoints();
		System.out.print(String.format("ID: %-5s Name: %-15s Age: %-5s State: %-14s Points: %s", swimID, swimName,
				swimAge, swimState, swimPoints));
		System.out.println("");
	}

	// prints out all swimmers ID, name and their points //
	public void printPoints() {
		String swimID = getID();
		String swimName = getName();
		int swimPoints = getPoints();
		String type = "Swimmer";
		System.out.print(
				String.format("ID: %-5s Name: %-15s Type: %-14s Points: %s", swimID, swimName, type, swimPoints));
		System.out.println("");
	}

}


public class Ozlympic {
	
	/*=====================================================
	 * =================== MAIN CLASS ===================
	 * ==================================================
	 */
	public static void main(String[] args) throws Exception{
		Driver mydriver = new Driver();
		mydriver.runDriver();
		 
		
	}

}

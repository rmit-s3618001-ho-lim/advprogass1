import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.hsqldb.Server;

public class Database {

	public Database(){}
	
	public void connection(){
		
		Server hsqlServer = null;
		Connection connection = null;
		

		
		
		try {
			//Registering the HSQLDB JDBC driver
			Class.forName("org.hsqldb.jdbcDriver");
			connection = DriverManager.getConnection("jdbc:hsqldb:AssignDB", "sa", "123");
			
			if (connection!= null){
				System.out.println("Connection created successfully");
				
			}else{
				System.out.println("Problem with creating connection");
			}
		
			//creating new Participants table
			connection.prepareStatement("DROP table participants if exists;").execute();
			connection.prepareStatement("DROP table gameResults if exists;").execute();
			
			connection.prepareStatement("CREATE table participants (ID varchar(10) not null, "
					+ "TYPE varchar(15) not null, NAME varchar(30) not null, AGE integer, "
					+ "STATE varchar(5) not null );").execute();
			
			connection.prepareStatement("CREATE table gameResults (GAMEID varchar(10) not null, "
					+ "OFFICIAL varchar(30) not null, ATHLETE varchar(30) not null, RESULT double, "
					+ "SCORE integer);").execute();
			
			connection.commit();
			
		}  catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}
	
	public void insertParticipants(){
		Server hsqlServer = null;
		Connection connection = null;
		ResultSet rs = null;
		Statement stmt = null;
		
		hsqlServer = new Server();
		hsqlServer.setLogWriter(null);
		hsqlServer.setSilent(true);
		hsqlServer.setDatabaseName(0, "AssignDB");
		hsqlServer.setDatabasePath(0, "file:MYDB");
		
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			connection = DriverManager.getConnection("jdbc:hsqldb:AssignDB", "sa", "123");
			
			/**INSERTING PARTICIPANTS **/
			/*Swimmers*/
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SW01', 'Swimmer', 'Bob', 34 , 'VIC');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SW02', 'Swimmer', 'Terry', 50, 'ACT');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SW03', 'Swimmer', 'James', 60, 'NT');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SW04', 'Swimmer', 'Lee', 29, 'QLD');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SW05', 'Swimmer', 'Lim', 32, 'VIC');").execute();
			
			/*Cyclists*/
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('CY01', 'Cyclists', 'Wayne', 34, 'VIC');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('CY02', 'Cyclists', 'Woody', 50, 'QLD');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('CY03', 'Cyclists', 'Bruce', 60, 'TAS');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('CY04', 'Cyclists', 'Lang', 19, 'VIC');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('CY05', 'Cyclists', 'Chris', 22, 'NSW');").execute();
			
			/*Sprinters*/
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SP01', 'Sprinters', 'Michael', 34, 'SA');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SP02', 'Sprinters', 'Justin', 50, 'TAS');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SP03', 'Sprinters', 'Tom', 40, 'ACT');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SP04', 'Sprinters', 'Jerry', 19, 'WA');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SP05', 'Sprinters', 'Bolt', 12, 'QLD');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SP06', 'Sprinters', 'Little Green', 2, 'VIC');").execute();
			
			/*superathletes*/
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SU01', 'Super', 'SuperJohn', 34, 'VIC');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SU02', 'Super', 'SuperBob', 50, 'NSW');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('SU03', 'Super', 'SuperJim', 60, 'VIC');").execute();
			
			/*official*/
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('OF01', 'Official', 'Jimmy Firecracker', 34, 'VIC');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('OF02', 'Official', 'John Smith', 50, 'WA');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('OF03', 'Official', 'Chicken McTasty', 23, 'TAS');").execute();
			connection.prepareStatement("INSERT into participants (id, type, name, age, state)" 
					+ "VALUES ('OF04', 'Official', 'Ducky McCrispy', 54, 'TAS');").execute();
       
			connection.commit();
			
	}catch (SQLException e2) {
		e2.printStackTrace();
	} catch (ClassNotFoundException e2) {
		e2.printStackTrace();
	}
	
	}
	
	public void getAllParticipants(ArrayList<Swimmer> fullSwim, ArrayList<Sprinters> fullSprint, 
			ArrayList<Cyclists> fullCycle, ArrayList<Superathletes> fullSuper, ArrayList<Official> fullOff){
		Server hsqlServer = null;
		Connection connection = null;
		ResultSet rs = null;
		Statement stmt = null;
		
		hsqlServer = new Server();
		hsqlServer.setLogWriter(null);
		hsqlServer.setSilent(true);
		hsqlServer.setDatabaseName(0, "AssignDB");
		hsqlServer.setDatabasePath(0, "file:MYDB");
		
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			connection = DriverManager.getConnection("jdbc:hsqldb:AssignDB", "sa", "123");
		
		    stmt = connection.createStatement();
		    rs = stmt.executeQuery(
		            "SELECT * FROM participants");

		    
		    while (rs.next()) {
		    	 String types = rs.getString("type");
			        if(types.equalsIgnoreCase("Swimmer")){
			        	Swimmer swim = new Swimmer(rs.getString("id"), 
				        		rs.getString("type"), rs.getString("name"),rs.getInt("age"), 
				        		rs.getString("state"));
			        	fullSwim.add(swim);
			        } else if(types.equalsIgnoreCase("Cyclists")){
			        	Cyclists cycle = new Cyclists(rs.getString("id"), 
				        		rs.getString("type"), rs.getString("name"),rs.getInt("age"), 
				        		rs.getString("state"));
			        	fullCycle.add(cycle);
			        } else if(types.equalsIgnoreCase("Sprinters")){
			        	Sprinters sprint = new Sprinters(rs.getString("id"), 
				        		rs.getString("type"), rs.getString("name"),rs.getInt("age"), 
				        		rs.getString("state"));
			        	fullSprint.add(sprint);
			        } else if(types.equalsIgnoreCase("Official")){
			        	Official off = new Official(rs.getString("id"), 
				        		rs.getString("type"), rs.getString("name"),rs.getInt("age"), 
				        		rs.getString("state"));
			        	fullOff.add(off);
			        } else{
			        	Superathletes sup = new Superathletes(rs.getString("id"), 
				        		rs.getString("type"), rs.getString("name"),rs.getInt("age"), 
				        		rs.getString("state"));
			        	fullSuper.add(sup);
			        }
		        
		    }
		    
		    connection.commit();
		
		}catch (SQLException e2) {
			e2.printStackTrace();
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		
	}
	
	public void updateResults(Game game, Athletes[] competitors){
		Server hsqlServer = null;
		Connection connection = null;
		ResultSet rs = null;
		Statement stmt = null;
		
		hsqlServer = new Server();
		hsqlServer.setLogWriter(null);
		hsqlServer.setSilent(true);
		hsqlServer.setDatabaseName(0, "AssignDB");
		hsqlServer.setDatabasePath(0, "file:MYDB");
		
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			connection = DriverManager.getConnection("jdbc:hsqldb:AssignDB", "sa", "123");
			
			
			String gameID = game.getGameID();
			String offName = game.getOfficial().getName();
			
			for(int i=0; i< competitors.length; i++){
				if(competitors[i] != null){
					String athName = competitors[i].getName();
					int time = competitors[i].getTime();
					int score = 0;
					if(i == 0){
						score = 5;
					}else if(i == 1){
						score = 3;
					}else if(i == 2){
						score = 1;
					}
					connection.prepareStatement("INSERT into gameResults (gameid, official, athlete, result, score)" 
							+ "VALUES ('"+gameID+"', '"+offName+"', '"+athName+"', '"+time+"',"
									+ " '"+score+"');").execute();
				}
				
			}
			
			stmt = connection.createStatement();
	         rs = stmt.executeQuery(
	            "SELECT * FROM gameResults");
	         
	         while(rs.next()){
	            System.out.println(rs.getString("gameID")+" | "+
	               rs.getString("official")+" | "+
	               rs.getString("athlete")+" | "+
	               rs.getInt("result")+" | "+
	            		rs.getInt("score"));
	         }
		
		    
		    
		}catch (SQLException e2) {
			e2.printStackTrace();
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		    
	}
	
	
	
}

package Exception;

public class GameFullException extends Exception{
		public GameFullException(String s){
			super(s);
		}
}

package Exception;

public class NoRefereeException extends Exception {
	public NoRefereeException (String s){
		super(s);
	}
}

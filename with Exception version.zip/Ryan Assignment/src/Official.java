import java.util.Arrays;
import java.util.Comparator;

public class Official extends Participant {

	/* official constructors */
	public Official(String IDs, String types, String names, int ages, String states) {
		super.ID = IDs;
		super.name = names;
		super.age = ages;
		super.state = states;
		super.type = types;
	}

	public Official() {
	}


	/* print out the official in current game details */
	public void print() {
		String offID = getID();
		String offName = getName();
		int offAge = getAge();
		String offState = getState();
		System.out.print(String.format("ID: %-5s Name: %-15s Age: %-5s State: %s", offID, offName, offAge, offState));
		System.out.println();
	}

	/*
	 * method to choose three winners based on the participants' race time for
	 * that game. the three winners are then given points based on their
	 * performance
	 */
	public void summariseScore(Athletes[] competitors, Game gam) {
		int min = Integer.MAX_VALUE;
		Athletes winner1 = null;
		Athletes winner2 = null;
		Athletes winner3 = null;
		/* choosing the first winner and giving him his points */
		for (int i = 0; i < competitors.length; i++) {
			if (competitors[i] != null) {
				if (competitors[i].getTime() < min) {
					min = competitors[i].getTime();
					winner1 = competitors[i];

				}
			}
		}
		gam.setWinner1(winner1);
		winner1.setPoints(5);

		/* choosing the second winner and giving him his points */
		min = Integer.MAX_VALUE;
		for (int i = 0; i < competitors.length; i++) {
			if (competitors[i] != null) {
				if (competitors[i].getTime() < min) {
					if (competitors[i] != winner1) {
						min = competitors[i].getTime();
						winner2 = competitors[i];
					}
				}
			}
		}
		gam.setWinner2(winner2);
		winner2.setPoints(3);

		/* choosing the last winner and giving him his points */
		min = Integer.MAX_VALUE;
		for (int i = 0; i < competitors.length; i++) {
			if (competitors[i] != null) {
				if (competitors[i].getTime() < min) {
					if (competitors[i] != winner1 && competitors[i] != winner2) {
						min = competitors[i].getTime();
						winner3 = competitors[i];
					}
				}
			}
		}
		gam.setWinner3(winner3);
		winner3.setPoints(1);	
		
		/*sorting the competitors according to their time */
		Arrays.sort(competitors, new Comparator<Athletes>(){
			public int compare(Athletes ath1, Athletes ath2) {
				if (ath1 == null && ath2 == null) {
	                return 0;
	            }
	            if (ath1 == null) {
	                return 1;
	            }
	            if (ath2 == null) {
	                return -1;
	            }
	            return ath1.compareTo(ath2);
			}});
	           
		/*printing out game results */
		System.out.print(String.format(
				"Game ID: %-2s  Official: %-18s ", gam.getGameID(), gam.getOfficial().getName()));
		System.out.println();
		
		int i=0;
		for(i = 0; i < competitors.length ; i++){
			if(competitors[i] != null){
				Athletes ath = competitors[i];
				if(ath == winner1){
					System.out.print(String.format(
							"ID: %-2s Name: %-18s Time: %-6d Points earned: 5", ath.getID(),
							ath.getName(), ath.getTime()));
				}else if(ath == winner2){
					System.out.print(String.format(
							"ID: %-2s Name: %-18s Time: %-6d Points earned: 3", ath.getID(),
							ath.getName(), ath.getTime()));
				}else if(ath == winner3){
					System.out.print(String.format(
							"ID: %-2s Name: %-18s Time: %-6d Points earned: 1", ath.getID(),
							ath.getName(), ath.getTime()));
				}else{
					System.out.print(String.format(
							"ID: %-2s Name: %-18s Time: %-6d Points earned: 0", ath.getID(),
							ath.getName(), ath.getTime()));
				}
				
				System.out.println();
			}
		   
		}

	}
	
	

}

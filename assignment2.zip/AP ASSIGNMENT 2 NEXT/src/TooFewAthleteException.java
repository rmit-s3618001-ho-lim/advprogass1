// author: Zhipeng Li s3581721

public class TooFewAthleteException extends Exception {
	public TooFewAthleteException(String s){
		super(s);
	}
}


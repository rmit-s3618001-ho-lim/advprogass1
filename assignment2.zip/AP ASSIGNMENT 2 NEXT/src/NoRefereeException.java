// author: Zhipeng Li s3581721

public class NoRefereeException extends Exception {
	public NoRefereeException (String s){
		super(s);
	}
}

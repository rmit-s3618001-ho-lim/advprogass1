// author: Zhipeng Li s3581721

public class WrongTypeException extends Exception {
	
		public WrongTypeException(String s){
			super(s);
		}
}


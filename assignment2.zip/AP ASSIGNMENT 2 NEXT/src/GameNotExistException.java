// author: Zhipeng Li s3581721

public class GameNotExistException extends Exception{
		public GameNotExistException(String s){
			super(s);
		}
}

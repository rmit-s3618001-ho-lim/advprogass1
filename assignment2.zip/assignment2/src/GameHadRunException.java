// author: Zhipeng Li s3581721

public class GameHadRunException extends Exception {
	public GameHadRunException(String s){
		super(s);
	}
}
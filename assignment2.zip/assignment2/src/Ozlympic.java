// author: Cherng Ho Lim s3618001

public class Ozlympic {
	
	/*=====================================================
	 * =================== MAIN CLASS ===================
	 * ==================================================
	 */
	public static void main(String[] args){
		Driver.launch(Driver.class);
		
	}

}

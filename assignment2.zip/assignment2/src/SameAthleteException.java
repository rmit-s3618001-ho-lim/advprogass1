// author: Zhipeng Li s3581721

public class SameAthleteException extends Exception {
	public SameAthleteException(String s){
		super(s);
	}
}

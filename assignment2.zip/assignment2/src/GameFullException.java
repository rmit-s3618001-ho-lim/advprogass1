// author: Zhipeng Li s3581721

public class GameFullException extends Exception{
		public GameFullException(String s){
			super(s);
		}
}

package TestCase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Game.Driver;
import Game.Official;

public class TestchooseOffical extends Driver {
	
	Official[] offreadylist = new Official[3];
	Official off1;
	Official off2;
	Official off3;
	
	
	
	@Before
	public void setUp() throws Exception {
		off1 = new Official("OF01", "Official", "Jimmy Firecracker", 34, "VIC");
		off2 = new Official("OF02", "Official", "John Smith", 50," WA")	;
		off3 = new Official("OF03", "Official", "Chicken McTasty", 23, "TAS");
		
		offreadylist[0] = off1;
		offreadylist[1] = off2;
		offreadylist[2] = off3;
		}

	@Test
	public void test1() {
		assertEquals(off1, chooseOfficial("OF01"));
	}
	@Test
	public void test2() {
		assertEquals(null, chooseOfficial("OF04"));
	}

}

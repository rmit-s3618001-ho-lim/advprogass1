package AP;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class setPointsTest {
	Swimmer swim;
	
	@Before
	public void setUp() throws Exception {
		swim = new Swimmer("S123", "Ben", 23, "AU");
		swim.setPoints(0);
	}

	@Test
	public void testSetPoints1 () {
        swim.setPoints(3);
		assertTrue(swim.getPoints()==3);
	}
	@Test
	public void testSetPoints2 () {
		swim.setPoints(3);	
		 swim.setPoints(3);
		assertTrue(swim.getPoints()==6);
	}
	@Test
	public void testSetPoints3 () {
		swim.setPoints(3);
		swim.setPoints(3);
		swim.setPoints(3);
		assertTrue(swim.getPoints()==9);
	}
}

package AP;



public class Ozlympic {
	
	/*=====================================================
	 * =================== MAIN CLASS ===================
	 * ==================================================
	 */
	public static void main(String[] args){
		Driver mydriver = new Driver();
		mydriver.runDriver();
		 
		
	}

}

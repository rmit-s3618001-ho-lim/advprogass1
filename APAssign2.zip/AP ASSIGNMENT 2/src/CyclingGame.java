

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class CyclingGame extends Game {

	// constructors for cycling game//
	public CyclingGame(String ID, Official off) {
		super(ID, off);
	}

	public CyclingGame() {
	}

	// generate a unique ID for each cycling game created//
	public String IDMaker(int count) {
		StringBuilder build = new StringBuilder();
		build.append("C");
		if (count <= 9) {
			build.append(0);
			build.append(String.valueOf(count));
		} else {
			build.append(String.valueOf(count));
		}
		return build.toString();

	}

	// randomly choosing cyclists or superathletes from respective array to
	// participate in current game
	// also ensure that the same athlete is not added to current game
	public void chooseCompetitors(Athletes[] competitors, Athletes[] theList) {
		Scanner scan = new Scanner(System.in);

		boolean sameguy = false;
		
		int count = competitors.length;

		System.out.println();
		System.out.println("To add an athlete into the game, enter his ID:");
		String ID = scan.nextLine();
		
		
		for (int i = 0; i < competitors.length; i++) {
			if (competitors[i] == null) {
				count--;
			}
		}

		/* check if same athlete is in game already of not */
		for (int j = 0; j < count; j++) {
			if (ID.equalsIgnoreCase(competitors[j].getID())) {
				sameguy = true;
			}
		}
		if (sameguy == true) {
			System.out.println("You cannot add the same guy");
		} else {
			int index = -1;
			/* check if id inputted is in list of athletes */
			for (int i = 0; i < theList.length; i++) {
				if (theList[i].getID().equalsIgnoreCase(ID)) {
					index = i;
					break;
				}
			}
			/* EXCEPTION */
			if (index == -1) {
				System.out.println("The ID inputted does not exist");
			} else {
				Athletes ath = theList[index];
				/* EXCEPTION whether swimmers or superathletes were chosen */
				if (ath instanceof Cyclists || ath instanceof Superathletes) {
					for (int i = 0; i < competitors.length; i++) {
						if (competitors[i] == null) {
							competitors[count] = ath;
							break;
						}
					}
					
				} else {
					System.out.println("You must input cyclists or supers");
				}

			}
		}

	}

	// print out current game details
		public void print() {
			String gameID = getGameID();
			System.out.println("--- GAME DETAILS ---");
			System.out.printf("ID: " + gameID);
			System.out.printf("   Type:  Cycling Game");
			System.out.println();
			if(getOfficial() != null){
				Official off = getOfficial();
				System.out.println();
				System.out.println("--- OFFICIAL DETAILS ---");
				off.print();
			}else{
				System.out.println();
				System.out.println("--- OFFICIAL DETAILS ---");
				System.out.println("There are no official in this game");
			}
		}

	// prints out swimming game details including their winners
	// prints out different message if the game was either cancelled or never
	// started
	public void printResults() {
		String gameID = getGameID();
		Official off = getOfficial();
		String type = "Cycling";
		Athletes win1 = getWinner1();
		Athletes win2 = getWinner2();
		Athletes win3 = getWinner3();
		if (win1 != null && win2 != null && win3 != null) {
			System.out.print(String.format(
					"Game ID: %-2s Type: %-9s Official: %-18s Winner 1: %-12s Winner 2: %-12s" + "Winner 3: %s", gameID,
					type, off.getName(), win1.getName(), win2.getName(), win3.getName()));
			System.out.println();
		} else {
			System.out.print(
					String.format("Game ID: %-2s Type: %-9s Official: %-20s (This game was cancelled or not started)",
							gameID, type, off.getName()));
			System.out.println();
		}
	}

}

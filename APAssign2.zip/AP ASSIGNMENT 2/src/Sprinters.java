


import java.util.Random;

public class Sprinters extends Athletes {

	/* sprinters constructors */
	public Sprinters(String IDs, String types, String names, int ages, String states) {
		super(IDs, types, names, ages, states);

	}

	public Sprinters() {
	}


	// randomly generate sprinters' race time for current game //
	public void compete(Game gam, Athletes run) {
		Random RNG = new Random();
		if (gam instanceof RunningGame) {
			int competeTime = RNG.nextInt(11) + 10;
			run.setTime(competeTime);
		} 

	}

	// prints out the sprinters who are participating in current game
	// information //
	public void print() {
		String sprintID = getID();
		String sprintName = getName();
		int sprintAge = getAge();
		String sprintState = getState();
		int sprintPoints = getPoints();
		System.out.print(String.format("ID: %-5s Name: %-15s Age: %-5s State: %-14s Points: %s", sprintID, sprintName,
				sprintAge, sprintState, sprintPoints));
		System.out.println("");
	}

	// prints out all sprinters ID, name and their points //
	public void printPoints() {
		String sprintID = getID();
		String sprintName = getName();
		int sprintPoints = getPoints();
		String type = "Sprinter";
		System.out.print(
				String.format("ID: %-5s Name: %-15s Type: %-14s Points: %s", sprintID, sprintName, type, sprintPoints));
		System.out.println("");
	}
}

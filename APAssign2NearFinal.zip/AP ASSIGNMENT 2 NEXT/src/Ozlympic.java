
public class Ozlympic {
	
	/*=====================================================
	 * =================== MAIN CLASS ===================
	 * ==================================================
	 */
	public static void main(String[] args){
		Driver.launch(Driver.class);
		
	}

}

package Exception;

public class WrongTypeException extends Exception {
	
		public WrongTypeException(String s){
			super(s);
		}
}


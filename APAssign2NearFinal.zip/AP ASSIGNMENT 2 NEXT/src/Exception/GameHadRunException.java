package Exception;

public class GameHadRunException extends Exception {
	public GameHadRunException(String s){
		super(s);
	}
}
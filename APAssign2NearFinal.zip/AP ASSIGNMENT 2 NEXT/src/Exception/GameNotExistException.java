package Exception;

public class GameNotExistException extends Exception{
		public GameNotExistException(String s){
			super(s);
		}
}

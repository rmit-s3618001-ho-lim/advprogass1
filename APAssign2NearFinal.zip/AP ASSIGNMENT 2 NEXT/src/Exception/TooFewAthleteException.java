package Exception;

public class TooFewAthleteException extends Exception {
	public TooFewAthleteException(String s){
		super(s);
	}
}


package Exception;

public class SameAthleteException extends Exception {
	public SameAthleteException(String s){
		super(s);
	}
}
